$(document).ready(function() {
    var navLinksArr = $(".nav-item");
    // toggle active nav links
    function removeActiveClass(addClassEmement) {
        $(navLinksArr).each(function(key, value) {

            if ($(value).hasClass("active"))
                $(value).removeClass("active");
        });



        if (addClassEmement)
            $(addClassEmement).parent().addClass("active");
    }

    removeActiveClass();
    new WOW().init();
    var wow;
    var aboutmecard = $("#aboutmecard");
    var aboutmesection = $("#aboutme");

    var iScrollPos = $(aboutmesection).height();
    var tolerance = $(aboutmecard).height();
    wow = new WOW({
        boxClass: 'wow', // default
        animateClass: 'animated', // default
        offset: iScrollPos, // default
        mobile: true, // default
        live: true // default
    });

    wow.init();
        $(aboutmecard).css({
        'visibility': 'hidden',
        'animation-name': 'none'
    });


    //    animation infosys
    var infosysLogo = $("#infosyslogo");
    var wowInfosyslogo = new WOW({
        boxClass: 'wow', // default
        animateClass: 'animated', // default
        offset: 0, // default
        mobile: true, // default
        live: true // default
    });
    var wowInfosysdetails = new WOW({
        boxClass: 'wow', // default
        animateClass: 'animated', // default
        offset: 0, // default
        mobile: true, // default
        live: true // default
    });
 
    // automatic active selection of nav links
    $(document).on('scroll', function() {
        if ($(document).scrollTop() < $("#aboutme").offset().top)
            removeActiveClass();
        if ($(document).scrollTop() >= $("#aboutme").offset().top - 1 && $(document).scrollTop() < $("#work").offset().top)
            removeActiveClass($("#aboutme-navlink"));
        if ($(document).scrollTop() >= $("#work").offset().top - 1 && $(document).scrollTop() < $("#qualifications").offset().top)
            removeActiveClass($("#work-navlink"));
        if ($(document).scrollTop() >= $("#qualifications").offset().top - 1 && $(document).scrollTop() < $("#project").offset().top)
            removeActiveClass($("#qualification-navlink"));
        if ($(document).scrollTop() >= $("#project").offset().top - 1)
            removeActiveClass();
    }, 250);

    $("#contactme-link").click(function() {
        removeActiveClass(this);

        $('html,body').animate({
            scrollTop: $("#contactme").offset().top
        }, 1000);
    });
    $("#aboutme-navlink").click(function() {
        removeActiveClass(this);
        $('html,body').animate({
            scrollTop: $("#aboutme").offset().top
        }, 1000);
    });
    $("#work-navlink").click(function() {
        removeActiveClass(this);
        $('html,body').animate({
            scrollTop: $("#work").offset().top
        }, 1000);
    });
    $("#qualification-navlink").click(function() {
        removeActiveClass(this);
        $('html,body').animate({
            scrollTop: $("#qualifications").offset().top
        }, 1000);
    });
    $("#myNameLogo").click(function() {
        removeActiveClass(this);
        $('html,body').animate({
            scrollTop: $("#sectionwelcome").offset().top
        }, 1000);
    });
 
    $("#send").click(function() {
        $("form").checkValidity();
        validateForm();
    });
    $("input,textarea").attr('touched',0);
    
    $("input,textarea").on('focus',function(event){
        
        $(this).attr('touched',1);
       
    }); var send = $("#send");
    $("form").on('keyup',function(event){
        
        
        switch (event.target.id) {
            case "form-contact-name":
            if(+$("#form-contact-name").attr('touched'))
            if(event.target.value == "")
            $("#"+event.target.id).addClass('is-invalid');
            else
            $("#"+event.target.id).removeClass('is-invalid').addClass("is-valid");
            break;
            case "form-contact-email":
            if(+$("#form-contact-email").attr('touched'))
            if(event.target.value == ""){
                $("#"+event.target.id).addClass('is-invalid');
                $('.invalid-feedback')[1].innerHTML = "Email is required";
            }
         
            else {
                var re = /^[a-zA-Z0-9.!#$%&’*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)*$/;
                if(!re.test(event.target.value)){
                    $("#"+event.target.id).addClass('is-invalid');
                    $('.invalid-feedback')[1].innerHTML = "Email format invalid";
                }
                else
                $("#"+event.target.id).removeClass('is-invalid').addClass("is-valid");
            }
            break;
            case "form-contact-subject":
            if(+$("#form-contact-subject").attr('touched'))
            if(event.target.value == "")
            $("#"+event.target.id).addClass('is-invalid');
            else
            $("#"+event.target.id).removeClass('is-invalid').addClass("is-valid");
            break;
            case "form-contact-message":
            if(+$("#form-contact-message").attr('touched'))
            if(event.target.value == "")
            $("#"+event.target.id).addClass('is-invalid');
            else
            $("#"+event.target.id).removeClass('is-invalid').addClass("is-valid");
        }
        if(!$("input,textarea").hasClass("is-invalid") && $("input[touched=1],textarea[touched=1]").length )
        $(send).removeClass("disabled");
        else
        $(send).addClass("disabled");
    });
    $(send).addClass("disabled");
    function validateForm() {
         
     var name = $("input[id=form-contact-name]");
     var subject = $("input[id=form-contact-subject]");
     var message = $("input[id=form-contact-message]");
     var email = $("input[id=form-contact-email]");
     
        if(!$(name).val() )
        return false
       
        if(!$(subject).val() )
        return false
       
       
        if(!$(email).val() )
        return false
       
        if(!$(message).val() )
        return false
       
        document.getElementById('status').innerHTML = "Sending...";
        formData = {
            'name': $(name).val(),
            'email': $(email).val(),
            'subject': $(subject).val(),
            'message': $(message).val()
        };


        $.ajax({
            url: "mail.php",
            type: "POST",
            data: formData,
            success: function(data, textStatus, jqXHR) {

                $('#status').text(data.message);
                if (data.code) //If mail was sent successfully, reset the form.
                    $('#contact-form').closest('form').find("input[type=text], textarea").val("");
            },
            error: function(jqXHR, textStatus, errorThrown) {
                $('#status').text(jqXHR);
            }
        });

    }



    $('#exampleModalLong').modal('handleUpdate');

});

// scroll stop time extension

(function($) {
    var on = $.fn.on,
        timer;
    $.fn.on = function() {
        var args = Array.apply(null, arguments);
        var last = args[args.length - 1];

        if (isNaN(last) || (last === 1 && args.pop())) return on.apply(this, args);

        var delay = args.pop();
        var fn = args.pop();

        args.push(function() {
            var self = this,
                params = arguments;
            clearTimeout(timer);
            timer = setTimeout(function() {
                fn.apply(self, params);
            }, delay);
        });

        return on.apply(this, args);
    };
}(this.jQuery || this.Zepto));